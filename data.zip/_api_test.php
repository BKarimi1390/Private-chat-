<?php
/* ============================================================
   Private Chat - single API endpoint
   POST api.php  body: {"action":"...", ...}
   GET  api.php?action=ping  for a readiness check
   ============================================================ */

require_once __DIR__ . '/lib.php';

$raw = file_get_contents('php://input');
$body = array();
if ($raw !== false && strlen($raw) > 0) {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
    }
}
if (!count($body) && count($_POST)) {
    $body = $_POST;
}

$action = '';
if (isset($body['action'])) {
    $action = (string) $body['action'];
} elseif (isset($_GET['action'])) {
    $action = (string) $_GET['action'];
}
$action = preg_replace('/[^a-zA-Z0-9._]/', '', $action);

function pc_str($body, $key, $max = 500)
{
    if (!isset($body[$key]) || !is_scalar($body[$key])) {
        return '';
    }
    $v = trim((string) $body[$key]);
    if (function_exists('mb_substr')) {
        return mb_substr($v, 0, $max, 'UTF-8');
    }
    return substr($v, 0, $max);
}

function pc_len($s)
{
    return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s);
}

try {
    switch ($action) {

        case 'ping':
            /* pc_db() self-installs: creates the SQLite file, the tables
               and the administrator account on the very first call. */
            $ready = true;
            $note = 'ready';
            try {
                pc_db()->query('SELECT 1 FROM users LIMIT 1')->fetch();
            } catch (Exception $e) {
                $ready = false;
                $note = 'database not ready';
            }
            pc_json(array(
                'ok' => true,
                'server' => 'private-chat',
                'api' => 2,
                'driver' => DB_DRIVER,
                'installed' => $ready,
                'autoInstall' => true,
                'note' => $note,
                'time' => pc_now_ms()
            ));
            break;

        /* The "health" action used to expose the database file path, the
           number of accounts and the number of stored messages on the
           sign-in card. It was removed because it leaked sensitive info
           to anyone without authentication. If you need that data, log in
           as administrator and use the Diagnostics screen. */

        case 'auth.register':
            $name = pc_str($body, 'name', 64);
            $handle = pc_norm_handle(pc_str($body, 'id', 32));
            $pass = (string) (isset($body['pass']) ? $body['pass'] : '');
            if (pc_len($name) < 2) {
                pc_fail('Enter the display name other people will see (2+ characters).');
            }
            if (!pc_valid_handle($handle)) {
                pc_fail('User IDs are 3-20 characters: letters, numbers, dots or underscores.');
            }
            if (strlen($pass) < 6) {
                pc_fail('Passwords must be at least 6 characters long.');
            }
            $db = pc_db();
            $st = $db->prepare('SELECT id FROM users WHERE handle = ?');
            $st->execute(array($handle));
            if ($st->fetch()) {
                pc_fail('@' . $handle . ' is already taken. Please pick another ID.');
            }
            $row = pc_create_user($name, $handle, $pass, 'member');
            $token = pc_start_session((int) $row['id']);
            $state = pc_load_state((int) $row['id']);
            pc_json(array(
                'ok' => true,
                'token' => $token,
                'user' => pc_public_user($row),
                'users' => pc_all_users(),
                'version' => $state['version'],
                'data' => $state['data'],
                'cursor' => 0
            ));
            break;

        case 'auth.login':
            $handle = pc_norm_handle(pc_str($body, 'id', 32));
            $pass = (string) (isset($body['pass']) ? $body['pass'] : '');
            if ($handle === '' || $pass === '') {
                pc_fail('Enter both your user ID and password.');
            }
            if (pc_rate_limited($handle)) {
                pc_fail('Too many failed attempts. Please wait a few minutes and try again.', 429);
            }
            $db = pc_db();
            $st = $db->prepare('SELECT * FROM users WHERE handle = ?');
            $st->execute(array($handle));
            $row = $st->fetch();
            if (!$row || !password_verify($pass, $row['pass_hash'])) {
                pc_log_fail($handle);
                pc_fail('Incorrect user ID or password.', 401);
            }
            if ($row['status'] === 'blocked') {
                pc_fail('This account has been suspended by an administrator.', 403);
            }
            $token = pc_start_session((int) $row['id']);
            $state = pc_load_state((int) $row['id']);
            pc_json(array(
                'ok' => true,
                'token' => $token,
                'user' => pc_public_user($row),
                'users' => pc_all_users(),
                'version' => $state['version'],
                'data' => $state['data']
            ));
            break;

        case 'auth.me':
            $me = pc_current_user($body);
            pc_json(array('ok' => true, 'user' => pc_public_user($me), 'users' => pc_all_users()));
            break;

        case 'auth.logout':
            $token = pc_token_from_request($body);
            if (preg_match('/^[a-f0-9]{16,64}$/', (string) $token)) {
                pc_db()->prepare('DELETE FROM sessions WHERE token = ?')->execute(array($token));
            }
            pc_json(array('ok' => true));
            break;

        case 'auth.changePassword':
            $me = pc_current_user($body);
            $old = (string) (isset($body['old']) ? $body['old'] : '');
            $new = (string) (isset($body['new']) ? $body['new'] : '');
            if (!password_verify($old, $me['pass_hash'])) {
                pc_fail('The current password is not correct.', 403);
            }
            if (strlen($new) < 6) {
                pc_fail('Passwords must be at least 6 characters long.');
            }
            pc_db()->prepare('UPDATE users SET pass_hash = ? WHERE id = ?')
                ->execute(array(password_hash($new, PASSWORD_DEFAULT), (int) $me['id']));
            pc_db()->prepare('DELETE FROM sessions WHERE user_id = ? AND token <> ?')
                ->execute(array((int) $me['id'], pc_token_from_request($body)));
            pc_json(array('ok' => true));
            break;

        case 'user.find':
            /* Server-side lookup of any account by ID. Used by the New
               conversation dialog so a brand-new account (one that the
               caller has not synchronised yet) can still be found. */
            $me = pc_current_user($body);
            $handle = pc_norm_handle(pc_str($body, 'id', 32));
            if ($handle === '') {
                pc_fail('Enter a user ID to look up.');
            }
            $db = pc_db();
            $st = $db->prepare('SELECT * FROM users WHERE handle = ?');
            $st->execute(array($handle));
            $row = $st->fetch();
            if (!$row) {
                pc_json(array(
                    'ok' => false,
                    'found' => false,
                    'error' => 'No account found with the ID @' . $handle . '.'
                ));
            }
            pc_json(array(
                'ok' => true,
                'found' => true,
                'user' => pc_public_user($row)
            ));
            break;

        case 'state.pull':
            $me = pc_current_user($body);
            $state = pc_load_state((int) $me['id']);
            pc_json(array(
                'ok' => true,
                'version' => $state['version'],
                'data' => $state['data'],
                'users' => pc_all_users(),
                'me' => pc_public_user($me)
            ));
            break;

        case 'state.push':
            $me = pc_current_user($body);
            $client = isset($body['data']) && is_array($body['data']) ? $body['data'] : null;
            if ($client === null) {
                pc_fail('Nothing to save.');
            }
            $state = pc_load_state((int) $me['id']);
            $merged = pc_merge_state($state['data'], $client);
            $version = pc_save_state((int) $me['id'], $merged);
            pc_json(array(
                'ok' => true,
                'version' => $version,
                'data' => $merged,
                'users' => pc_all_users()
            ));
            break;

        case 'msg.send':
            $me = pc_current_user($body);
            $items = isset($body['items']) && is_array($body['items']) ? $body['items'] : array();
            $sent = array();
            $skipped = array();
            foreach ($items as $it) {
                if (!is_array($it)) {
                    continue;
                }
                $to = isset($it['to']) ? (int) $it['to'] : 0;
                $peer = $to > 0 ? pc_find_user($to) : null;
                if (!$peer) {
                    $skipped[] = isset($it['mid']) ? (int) $it['mid'] : 0;
                    continue;
                }
                pc_queue_message((int) $me['id'], $to, $it);
                $sent[] = isset($it['mid']) ? (int) $it['mid'] : 0;
            }
            pc_json(array('ok' => true, 'sent' => $sent, 'skipped' => $skipped));
            break;

        case 'msg.fetch':
            /* Long-poll support: pass wait=N (seconds, capped at 20) and
               the server holds the connection open until a new message
               arrives or the deadline expires. This gives near-instant
               delivery between two clients without WebSockets. */
            $me = pc_current_user($body);
            $since = isset($body['since']) ? (int) $body['since'] : 0;
            $wait = isset($body['wait']) ? max(0, min(20, (int) $body['wait'])) : 0;
            if ($wait > 0) {
                @set_time_limit(max(30, $wait + 10));
                @ini_set('max_execution_time', max(30, $wait + 10));
            }
            $deadline = pc_now_ms() + $wait * 1000;
            $res = pc_fetch_messages((int) $me['id'], $since);
            while ($wait > 0 && count($res['items']) === 0 && pc_now_ms() < $deadline) {
                usleep(700000); /* 0.7s between checks */
                $res = pc_fetch_messages((int) $me['id'], $since);
            }
            pc_json(array('ok' => true, 'items' => $res['items'], 'cursor' => $res['cursor']));
            break;

        case 'msg.cursor':
            $me = pc_current_user($body);
            pc_json(array('ok' => true, 'cursor' => pc_message_cursor((int) $me['id'])));
            break;

        case 'admin.syncUsers':
            $me = pc_current_user($body);
            pc_require_admin($me);
            $list = isset($body['users']) && is_array($body['users']) ? $body['users'] : array();
            $db = pc_db();
            foreach ($list as $u) {
                if (!is_array($u) || !isset($u['id'])) {
                    continue;
                }
                $id = (int) $u['id'];
                if ($id <= 0) {
                    continue;
                }
                $name = isset($u['name']) ? (string) $u['name'] : '';
                $status = (isset($u['status']) && $u['status'] === 'blocked') ? 'blocked' : 'active';
                $pro = isset($u['proDays']) ? max(0, (int) $u['proDays']) : 0;
                $rep = isset($u['reports']) ? max(0, (int) $u['reports']) : 0;
                $st = $db->prepare('UPDATE users SET name = ?, status = ?, pro_days = ?, reports = ? WHERE id = ? AND role <> \'admin\'');
                $st->execute(array($name, $status, $pro, $rep, $id));
                if ($status === 'blocked') {
                    $db->prepare('DELETE FROM sessions WHERE user_id = ?')->execute(array($id));
                }
            }
            pc_json(array('ok' => true, 'users' => pc_all_users()));
            break;

        case 'admin.deleteUser':
            $me = pc_current_user($body);
            pc_require_admin($me);
            $uid = isset($body['uid']) ? (int) $body['uid'] : 0;
            if ($uid <= 0) {
                pc_fail('Unknown member.');
            }
            $peer = pc_find_user($uid);
            if (!$peer) {
                pc_json(array('ok' => true, 'freed' => '', 'users' => pc_all_users()));
            }
            if ($peer['role'] === 'admin') {
                pc_fail('The administrator account cannot be deleted.', 403);
            }
            pc_delete_user($uid);
            pc_json(array('ok' => true, 'freed' => '@' . $peer['handle'], 'users' => pc_all_users()));
            break;

        case 'admin.setPassword':
            $me = pc_current_user($body);
            pc_require_admin($me);
            $uid = isset($body['uid']) ? (int) $body['uid'] : 0;
            $new = (string) (isset($body['pass']) ? $body['pass'] : '');
            if ($uid <= 0 || !pc_find_user($uid)) {
                pc_fail('Unknown member.');
            }
            if (strlen($new) < 6) {
                pc_fail('Passwords must be at least 6 characters long.');
            }
            $db = pc_db();
            $db->prepare('UPDATE users SET pass_hash = ? WHERE id = ?')
                ->execute(array(password_hash($new, PASSWORD_DEFAULT), $uid));
            $db->prepare('DELETE FROM sessions WHERE user_id = ?')->execute(array($uid));
            pc_json(array('ok' => true, 'users' => pc_all_users()));
            break;

        case 'admin.reset':
            $me = pc_current_user($body);
            pc_require_admin($me);
            $db = pc_db();
            $db->exec('DELETE FROM messages');
            $db->exec('DELETE FROM login_fails');
            $ids = array();
            foreach ($db->query('SELECT id FROM users') as $r) {
                $ids[] = (int) $r['id'];
            }
            foreach ($ids as $id) {
                pc_reset_state($id);
            }
            pc_json(array('ok' => true, 'accounts' => count($ids)));
            break;

        case '':
            pc_fail('No action given.', 400);
            break;

        default:
            pc_fail('Unknown action: ' . $action, 404);
    }
} catch (Exception $e) {
    pc_fail('Server error' . (DEBUG_ERRORS ? ': ' . $e->getMessage() : '. Enable DEBUG_ERRORS in config.php for details.'), 500);
}
